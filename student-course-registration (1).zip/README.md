# Student Course Registration System

React + Vite project for the Week-6.1 DevOps and Fullstack lab assignment.

## Requirements

- Node.js
- npm
- VS Code

## Run the project

Open the project folder in VS Code, then open Terminal and run:

```bash
npm install
npm run dev
```

Open the localhost address shown by Vite.

## Features

- Student profile
- Available course list
- Reusable Course component
- Props
- React useState
- Register course
- Remove course
- Conditional rendering
- Search courses
- Department filter
- Course credits
- Total registered credits
- Duplicate registration prevention
- Responsive CSS
