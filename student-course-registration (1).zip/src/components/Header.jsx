function Header() {
  return (
    <header className="header">
      <div>
        <h1>ABC University</h1>
        <p>Student Course Registration System</p>
      </div>

      <nav>
        <a href="#home">Home</a>
        <a href="#courses">Courses</a>
        <a href="#registration">Registration</a>
      </nav>
    </header>
  );
}

export default Header;