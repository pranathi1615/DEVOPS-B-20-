function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 ABC University</p>
      <p>Student Course Registration System · React + Vite</p>
    </footer>
  );
}

export default Footer;