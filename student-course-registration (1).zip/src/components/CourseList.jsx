import Course from "./Course";

function CourseList({
  courses,
  onRegister,
  registeredCourses,
  search,
  department,
}) {
  const filteredCourses = courses.filter((course) => {
    const matchesSearch = course.name
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchesDepartment =
      department === "All" || course.department === department;

    return matchesSearch && matchesDepartment;
  });

  return (
    <section id="courses">
      <div className="section-heading">
        <div>
          <h2>Available Courses</h2>
          <p className="section-subtitle">
            Choose courses for the current semester.
          </p>
        </div>
        <span className="count-badge">
          {filteredCourses.length} course{filteredCourses.length !== 1 ? "s" : ""}
        </span>
      </div>

      {filteredCourses.length === 0 ? (
        <div className="empty-box">
          <h3>No courses found</h3>
          <p>Try a different course name or department.</p>
        </div>
      ) : (
        <div className="course-grid">
          {filteredCourses.map((course) => (
            <Course
              key={course.code}
              course={course}
              onRegister={onRegister}
              isRegistered={registeredCourses.some(
                (item) => item.code === course.code
              )}
            />
          ))}
        </div>
      )}
    </section>
  );
}

export default CourseList;