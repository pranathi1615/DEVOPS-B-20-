function Registration({ registeredCourses, onRemove }) {
  const totalCredits = registeredCourses.reduce(
    (total, course) => total + course.credits,
    0
  );

  return (
    <section id="registration" className="registration">
      <div className="section-heading">
        <div>
          <h2>Registered Courses</h2>
          <p className="section-subtitle">
            Your selected courses for this semester.
          </p>
        </div>
        <span className="count-badge">
          {registeredCourses.length} selected
        </span>
      </div>

      {registeredCourses.length === 0 ? (
        <div className="empty-box">
          <h3>No courses are registered</h3>
          <p>Register a course above to see it here.</p>
        </div>
      ) : (
        <>
          <div className="registered-list">
            {registeredCourses.map((course) => (
              <div className="registered-course" key={course.code}>
                <div>
                  <span className="course-code">{course.code}</span>
                  <h3>{course.name}</h3>
                  <p>
                    {course.department} · {course.credits} Credits
                  </p>
                </div>

                <button
                  className="remove-button"
                  onClick={() => onRemove(course.code)}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>

          <div className="total-credits">
            <span>Total Registered Credits</span>
            <strong>{totalCredits}</strong>
          </div>
        </>
      )}
    </section>
  );
}

export default Registration;