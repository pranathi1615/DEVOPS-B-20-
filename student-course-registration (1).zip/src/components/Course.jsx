function Course({ course, onRegister, isRegistered }) {
  return (
    <article className="course-card">
      <div className="course-top">
        <span className="course-code">{course.code}</span>
        <span className="credit-badge">{course.credits} Credits</span>
      </div>

      <h3>{course.name}</h3>
      <p className="department">{course.department}</p>

      <button
        className="register-button"
        onClick={() => onRegister(course)}
        disabled={isRegistered}
      >
        {isRegistered ? "✓ Registered" : "Register Course"}
      </button>
    </article>
  );
}

export default Course;