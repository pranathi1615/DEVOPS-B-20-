function StudentProfile({ student }) {
  return (
    <section className="profile">
      <div className="section-heading">
        <h2>Student Profile</h2>
        <span className="badge">Active Student</span>
      </div>

      <div className="profile-grid">
        <div>
          <span className="label">Name</span>
          <strong>{student.name}</strong>
        </div>

        <div>
          <span className="label">Student ID</span>
          <strong>{student.id}</strong>
        </div>

        <div>
          <span className="label">Department</span>
          <strong>{student.department}</strong>
        </div>

        <div>
          <span className="label">Email</span>
          <strong>{student.email}</strong>
        </div>
      </div>
    </section>
  );
}

export default StudentProfile;