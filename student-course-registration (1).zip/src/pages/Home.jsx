import { useState } from "react";
import StudentProfile from "../components/StudentProfile";
import CourseList from "../components/CourseList";
import Registration from "../components/Registration";

function Home() {
  const student = {
    name: "Giri Giridhar",
    id: "CSE2026001",
    department: "Computer Science Engineering",
    email: "giri@example.com",
  };

  const courses = [
    {
      code: "CS101",
      name: "Introduction to Programming",
      department: "CSE",
      credits: 4,
    },
    {
      code: "CS102",
      name: "Data Structures",
      department: "CSE",
      credits: 4,
    },
    {
      code: "CS103",
      name: "Database Management Systems",
      department: "CSE",
      credits: 3,
    },
    {
      code: "AI101",
      name: "Artificial Intelligence",
      department: "AI",
      credits: 4,
    },
    {
      code: "AI102",
      name: "Machine Learning",
      department: "AI",
      credits: 4,
    },
    {
      code: "ECE101",
      name: "Digital Electronics",
      department: "ECE",
      credits: 3,
    },
    {
      code: "ME101",
      name: "Engineering Mechanics",
      department: "ME",
      credits: 3,
    },
  ];

  const [registeredCourses, setRegisteredCourses] = useState([]);
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("All");

  function handleRegister(course) {
    const alreadyRegistered = registeredCourses.some(
      (item) => item.code === course.code
    );

    if (!alreadyRegistered) {
      setRegisteredCourses((currentCourses) => [
        ...currentCourses,
        course,
      ]);
    }
  }

  function handleRemove(courseCode) {
    setRegisteredCourses((currentCourses) =>
      currentCourses.filter((course) => course.code !== courseCode)
    );
  }

  return (
    <main id="home" className="container">
      <StudentProfile student={student} />

      <section className="filters">
        <div className="filter-item">
          <label htmlFor="course-search">Search Course</label>
          <input
            id="course-search"
            type="text"
            placeholder="Search by course name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="filter-item">
          <label htmlFor="department-filter">Department</label>
          <select
            id="department-filter"
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
          >
            <option value="All">All Departments</option>
            <option value="CSE">CSE</option>
            <option value="AI">AI</option>
            <option value="ECE">ECE</option>
            <option value="ME">ME</option>
          </select>
        </div>
      </section>

      <CourseList
        courses={courses}
        onRegister={handleRegister}
        registeredCourses={registeredCourses}
        search={search}
        department={department}
      />

      <Registration
        registeredCourses={registeredCourses}
        onRemove={handleRemove}
      />
    </main>
  );
}

export default Home;