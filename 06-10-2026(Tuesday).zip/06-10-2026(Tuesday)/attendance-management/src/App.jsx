import { useState } from "react";
import Header from "./components/Header";
import StudentList from "./components/StudentList";
import Summary from "./components/Summary";

const initialStudents = [
  {
    id: 1,
    name: "Rahul",
    rollNumber: "CSE101",
    branch: "CSE",
    attendance: 82,
    present: 0,
    absent: 0
  },
  {
    id: 2,
    name: "Priya",
    rollNumber: "CSE102",
    branch: "CSE",
    attendance: 68,
    present: 0,
    absent: 0
  },
  {
    id: 3,
    name: "Arjun",
    rollNumber: "CSE103",
    branch: "CSE",
    attendance: 91,
    present: 0,
    absent: 0
  }
];

function App() {

  const [students, setStudents] = useState(initialStudents);

  const [search, setSearch] = useState("");

  // Mark student Present
  const markPresent = (id) => {

    setStudents(
      students.map((student) => {

        if (student.id === id) {

          return {
            ...student,
            present: student.present + 1,
            attendance: Math.min(100, student.attendance + 1)
          };

        }

        return student;

      })
    );

  };

  // Mark student Absent
  const markAbsent = (id) => {

    setStudents(
      students.map((student) => {

        if (student.id === id) {

          return {
            ...student,
            absent: student.absent + 1,
            attendance: Math.max(0, student.attendance - 1)
          };

        }

        return student;

      })
    );

  };

  // Reset
  const resetAttendance = () => {

    setStudents(
      initialStudents.map((student) => ({
        ...student
      }))
    );

  };

  // Search
  const filteredStudents = students.filter((student) =>
    `${student.name} ${student.rollNumber} ${student.branch}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  // Summary
  const presentCount = students.reduce(
    (total, student) => total + student.present,
    0
  );

  const absentCount = students.reduce(
    (total, student) => total + student.absent,
    0
  );

  const eligibleCount = students.filter(
    (student) => student.attendance >= 75
  ).length;

  return (
    <div>

      <Header />

      <main className="container">

        {/* Search */}
        <div className="controls">

          <input
            type="text"
            placeholder="Search student..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <button onClick={resetAttendance}>
            Reset Attendance
          </button>

        </div>

        {/* Summary */}
        <Summary
          students={students}
          presentCount={presentCount}
          absentCount={absentCount}
          eligibleCount={eligibleCount}
        />

        {/* Students */}
        <StudentList
          students={filteredStudents}
          onPresent={markPresent}
          onAbsent={markAbsent}
        />

      </main>

    </div>
  );
}

export default App;