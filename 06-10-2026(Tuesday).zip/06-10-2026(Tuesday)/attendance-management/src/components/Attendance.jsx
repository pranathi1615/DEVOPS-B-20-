function Attendance({
  attendance,
  present,
  absent,
  onPresent,
  onAbsent
}) {

  return (

    <div className="attendance">

      <h2>
        {attendance}%
      </h2>

      <div className="progress">

        <div
          className="progress-bar"
          style={{
            width: `${attendance}%`
          }}
        >
        </div>

      </div>

      <p>
        Present: {present}
      </p>

      <p>
        Absent: {absent}
      </p>

      <button
        className="present"
        onClick={onPresent}
      >
        Present
      </button>

      <button
        className="absent"
        onClick={onAbsent}
      >
        Absent
      </button>

    </div>

  );

}

export default Attendance;