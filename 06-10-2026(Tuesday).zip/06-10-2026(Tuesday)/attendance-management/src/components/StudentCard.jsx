import Attendance from "./Attendance";

function StudentCard({
  name,
  rollNumber,
  branch,
  attendance,
  present,
  absent,
  onPresent,
  onAbsent
}) {

  const eligible = attendance >= 75;

  return (

    <div className="student-card">

      <h3>{name}</h3>

      <p>
        <b>Roll Number:</b> {rollNumber}
      </p>

      <p>
        <b>Branch:</b> {branch}
      </p>

      <Attendance

        attendance={attendance}

        present={present}

        absent={absent}

        onPresent={onPresent}

        onAbsent={onAbsent}

      />

      <h3 className={eligible ? "eligible" : "not-eligible"}>

        {eligible
          ? "Eligible"
          : "Not Eligible"}

      </h3>

    </div>

  );

}

export default StudentCard;