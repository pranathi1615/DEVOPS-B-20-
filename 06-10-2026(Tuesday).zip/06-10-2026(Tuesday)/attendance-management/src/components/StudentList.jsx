import StudentCard from "./StudentCard";

function StudentList({
  students,
  onPresent,
  onAbsent
}) {

  return (
    <section>

      <h2>Student List</h2>

      <div className="student-grid">

        {students.map((student) => (

          <StudentCard

            key={student.id}

            name={student.name}

            rollNumber={student.rollNumber}

            branch={student.branch}

            attendance={student.attendance}

            present={student.present}

            absent={student.absent}

            onPresent={() => onPresent(student.id)}

            onAbsent={() => onAbsent(student.id)}

          />

        ))}

      </div>

    </section>
  );

}

export default StudentList;