function Header() {

  return (
    <header className="header">

      <h1>
        Student Attendance Management System
      </h1>

      <p>
        College Attendance Dashboard
      </p>

    </header>
  );

}

export default Header;