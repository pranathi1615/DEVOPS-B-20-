function Summary({
  students,
  presentCount,
  absentCount,
  eligibleCount
}) {

  const averageAttendance =
    students.length === 0
      ? 0
      : Math.round(
          students.reduce(
            (total, student) =>
              total + student.attendance,
            0
          ) / students.length
        );

  return (

    <div className="summary">

      <div className="summary-card">
        <h3>Total Students</h3>
        <p>{students.length}</p>
      </div>

      <div className="summary-card">
        <h3>Present</h3>
        <p>{presentCount}</p>
      </div>

      <div className="summary-card">
        <h3>Absent</h3>
        <p>{absentCount}</p>
      </div>

      <div className="summary-card">
        <h3>Eligible</h3>
        <p>{eligibleCount}</p>
      </div>

      <div className="summary-card">
        <h3>Average Attendance</h3>
        <p>{averageAttendance}%</p>
      </div>

    </div>

  );

}

export default Summary;