import { Link } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";

export default function BookCard({ book }) {
  const { addToCart } = useStore();
  return (
    <div className="card">
      <h3>{book.title}</h3>
      <p className="muted">{book.author} • {book.category}</p>
      <p><strong>₹{book.price}</strong></p>
      <div className="row">
        <Link className="btn" to={`/books/${book.id}`}>View Details</Link>
        <button className="btn secondary" onClick={() => addToCart(book)}>Add to Cart</button>
      </div>
    </div>
  );
}
