import { Link } from "react-router-dom";

export default function Category({ name, count }) {
  return (
    <Link className="card category" to={`/books?category=${encodeURIComponent(name)}`}>
      <h3>{name}</h3>
      <p className="muted">{count} book(s)</p>
    </Link>
  );
}
