import { NavLink } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";

export default function Navigation() {
  const { cart } = useStore();
  return (
    <nav className="nav">
      <NavLink to="/" end>Home</NavLink>
      <NavLink to="/books">Books</NavLink>
      <NavLink to="/categories">Categories</NavLink>
      <NavLink to="/cart">Cart ({cart.length})</NavLink>
      <NavLink to="/profile">Profile</NavLink>
    </nav>
  );
}
