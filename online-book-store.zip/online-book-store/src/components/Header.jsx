import Navigation from "./Navigation.jsx";

export default function Header() {
  return (
    <header className="header">
      <h1>Online Book Store</h1>
      <Navigation />
    </header>
  );
}
