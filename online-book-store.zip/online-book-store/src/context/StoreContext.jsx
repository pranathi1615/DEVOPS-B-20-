import { createContext, useContext, useState } from "react";

const StoreContext = createContext(null);

export function StoreProvider({ children }) {
  const [cart, setCart] = useState([]);
  const [recent, setRecent] = useState([]);

  const addToCart = (book) =>
    setCart((c) => (c.some((b) => b.id === book.id) ? c : [...c, book]));
  const removeFromCart = (id) => setCart((c) => c.filter((b) => b.id !== id));
  const addRecent = (book) =>
    setRecent((r) => [book, ...r.filter((b) => b.id !== book.id)].slice(0, 5));

  return (
    <StoreContext.Provider value={{ cart, recent, addToCart, removeFromCart, addRecent }}>
      {children}
    </StoreContext.Provider>
  );
}

export const useStore = () => useContext(StoreContext);
