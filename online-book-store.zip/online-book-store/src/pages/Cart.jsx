import { Link } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";

export default function Cart() {
  const { cart, removeFromCart } = useStore();
  const total = cart.reduce((sum, b) => sum + b.price, 0);

  return (
    <section>
      <h2>Your Cart</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty. <Link to="/books">Browse books</Link></p>
      ) : (
        <>
          <ul className="cart-list">
            {cart.map((b) => (
              <li key={b.id}>
                <span>{b.title} — ₹{b.price}</span>
                <button className="btn secondary" onClick={() => removeFromCart(b.id)}>Remove</button>
              </li>
            ))}
          </ul>
          <h3>Total: ₹{total}</h3>
        </>
      )}
    </section>
  );
}
