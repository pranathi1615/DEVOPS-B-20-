export default function Profile() {
  return (
    <section>
      <h2>Profile</h2>
      <p><strong>Name:</strong> Book Lover</p>
      <p><strong>Email:</strong> booklover@example.com</p>
      <p><strong>Membership:</strong> Standard</p>
    </section>
  );
}
