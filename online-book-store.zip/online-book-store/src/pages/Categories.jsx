import { books, categories } from "../data/books.js";
import Category from "../components/Category.jsx";

export default function Categories() {
  return (
    <section>
      <h2>Categories</h2>
      <div className="grid">
        {categories.map((c) => (
          <Category key={c} name={c} count={books.filter((b) => b.category === c).length} />
        ))}
      </div>
    </section>
  );
}
