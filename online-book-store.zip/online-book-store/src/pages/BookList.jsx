import { useSearchParams } from "react-router-dom";
import { books, categories } from "../data/books.js";
import BookCard from "../components/BookCard.jsx";

export default function BookList() {
  const [params, setParams] = useSearchParams();
  const q = params.get("q") || "";
  const category = params.get("category") || "";

  const update = (key, value) => {
    const next = new URLSearchParams(params);
    value ? next.set(key, value) : next.delete(key);
    setParams(next);
  };

  const filtered = books.filter(
    (b) =>
      b.title.toLowerCase().includes(q.toLowerCase()) &&
      (!category || b.category === category)
  );

  return (
    <section>
      <h2>Books</h2>
      <div className="row">
        <input
          placeholder="Search books..."
          value={q}
          onChange={(e) => update("q", e.target.value)}
        />
        <select value={category} onChange={(e) => update("category", e.target.value)}>
          <option value="">All Categories</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {filtered.length === 0 ? (
        <p className="error">No books match your search.</p>
      ) : (
        <div className="grid">
          {filtered.map((b) => <BookCard key={b.id} book={b} />)}
        </div>
      )}
    </section>
  );
}
