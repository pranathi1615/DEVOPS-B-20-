import { Link } from "react-router-dom";
import { useStore } from "../context/StoreContext.jsx";

export default function Home() {
  const { recent } = useStore();
  return (
    <section>
      <h2>Welcome to the Online Book Store</h2>
      <p>Browse books, explore categories and add your favourites to the cart.</p>
      <Link className="btn" to="/books">Browse Books</Link>

      <h3>Recently Viewed</h3>
      {recent.length === 0 ? (
        <p className="muted">No books viewed yet.</p>
      ) : (
        <ul>
          {recent.map((b) => (
            <li key={b.id}><Link to={`/books/${b.id}`}>{b.title}</Link></li>
          ))}
        </ul>
      )}
    </section>
  );
}
