import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { books } from "../data/books.js";
import { useStore } from "../context/StoreContext.jsx";

export default function BookDetails() {
  const { bookId } = useParams();
  const navigate = useNavigate();
  const { addToCart, addRecent } = useStore();

  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // Runs on mount AND whenever bookId changes
  useEffect(() => {
    console.log("Loading book details:", bookId);
    setLoading(true);
    setError("");
    setBook(null);

    const timer = setTimeout(() => {
      const found = books.find((b) => b.id === bookId);
      if (found) {
        setBook(found);
        addRecent(found);
      } else {
        setError(`Book with ID "${bookId}" was not found.`);
      }
      setLoading(false);
    }, 600);

    // Cleanup: runs when leaving the page or before bookId changes
    return () => {
      console.log("Leaving book details:", bookId);
      clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookId]);

  if (loading) return <p className="loading">Loading book details...</p>;

  if (error)
    return (
      <div>
        <p className="error">{error}</p>
        <button className="btn" onClick={() => navigate("/books")}>Back to Books</button>
      </div>
    );

  const index = books.findIndex((b) => b.id === book.id);
  const prev = books[index - 1];
  const next = books[index + 1];

  return (
    <section className="details">
      <h2>{book.title}</h2>
      <p className="muted">by {book.author} • {book.category}</p>
      <p>{book.description}</p>
      <p><strong>Price: ₹{book.price}</strong></p>

      <div className="row">
        <button className="btn" onClick={() => addToCart(book)}>Add to Cart</button>
        <button className="btn secondary" onClick={() => navigate(-1)}>Go Back</button>
        <button className="btn secondary" onClick={() => navigate("/cart")}>Go to Cart</button>
      </div>

      <div className="row pager">
        {prev ? <Link to={`/books/${prev.id}`}>← Previous: {prev.title}</Link> : <span />}
        {next ? <Link to={`/books/${next.id}`}>Next: {next.title} →</Link> : <span />}
      </div>
    </section>
  );
}
