export const books = [
  { id: "B101", title: "Python Programming", author: "Guido Mentor", category: "Programming", price: 450, description: "Learn Python from basics to advanced concepts with hands-on examples." },
  { id: "B102", title: "Web Development", author: "Tim Builder", category: "Web", price: 550, description: "HTML, CSS, JavaScript and modern frameworks for building websites." },
  { id: "B103", title: "Machine Learning", author: "Andrew Learner", category: "AI", price: 650, description: "Introduction to supervised, unsupervised learning and model evaluation." },
  { id: "B104", title: "Data Structures", author: "Donald Coder", category: "Programming", price: 400, description: "Arrays, linked lists, trees, graphs and their algorithms." },
  { id: "B105", title: "React in Action", author: "Jordan Walke", category: "Web", price: 500, description: "Build interactive single page applications using React." },
  { id: "B106", title: "Deep Learning Basics", author: "Yann Neural", category: "AI", price: 700, description: "Neural networks, CNNs and RNNs explained step by step." },
];

export const categories = ["Programming", "Web", "AI"];

// Simulates an API call (used for lifecycle / loading demo)
export function fetchBookById(id) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      const book = books.find((b) => b.id === id);
      book ? resolve(book) : reject(new Error(`Book "${id}" was not found.`));
    }, 700);
    // allow caller to cancel
    fetchBookById.lastTimer = timer;
  });
}
