# Online Book Store (React Router + Lifecycle)

Single Page Application built with React, Vite and react-router-dom.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:5173

## Routes
| Path | Page |
|------|------|
| `/` | Home |
| `/books` | BookList (supports `?q=` search and `?category=` filter) |
| `/books/:bookId` | BookDetails (e.g. `/books/B101`) |
| `/categories` | Categories |
| `/cart` | Cart |
| `/profile` | Profile |
| `*` | 404 NotFound |

## Features
- `useParams`, `Link`/`NavLink`, `useNavigate`, `useSearchParams`
- `useEffect` in BookDetails: load on mount, re-run on `bookId` change, loading message, cleanup on leave
- Error handling for unknown book IDs, 404 page
- Bonus: search, category filter, add/remove cart, previous/next book, recently viewed
